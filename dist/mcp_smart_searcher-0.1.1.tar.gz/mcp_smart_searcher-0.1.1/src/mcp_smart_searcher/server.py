"""
MCP Smart Searcher - A smart MCP server for multi-engine web search with AI-powered results
"""

import asyncio
import os
import re
import urllib.parse
from typing import Any

import httpx
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP

# Create FastMCP server instance (required for mcp dev/inspector)
mcp = FastMCP("smart-searcher")

# Configuration from environment variables
DEFAULT_SEARCH_ENGINE = os.getenv("DEFAULT_SEARCH_ENGINE", "bing")
ALLOWED_SEARCH_ENGINES = os.getenv("ALLOWED_SEARCH_ENGINES", "").split(",") if os.getenv("ALLOWED_SEARCH_ENGINES") else None
BRAVE_API_KEY = os.getenv("BRAVE_API_KEY", "")
EXA_API_KEY = os.getenv("EXA_API_KEY", "")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
USE_PROXY = os.getenv("USE_PROXY", "false").lower() == "true"
PROXY_URL = os.getenv("PROXY_URL", "http://127.0.0.1:7890")
# Comma-separated list of engines that should use proxy. Empty means ALL engines use proxy (legacy behavior).
PROXY_ENGINES = [e.strip() for e in os.getenv("PROXY_ENGINES", "").split(",") if e.strip()] if os.getenv("PROXY_ENGINES") else None


# User agent for requests
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# Supported search engines
ALL_ENGINES = ["bing", "duckduckgo", "brave", "baidu", "juejin", "github", "github_code", "tavily"]


def get_proxy_config(engine: str = None) -> dict:
    """Get proxy configuration for a specific engine.

    Args:
        engine: The search engine name. If None, returns global proxy config.

    Returns:
        Dict with 'proxy' key if proxy is enabled for this engine.
    """
    if not USE_PROXY:
        return {}
    # If PROXY_ENGINES is set, only those engines use proxy
    if PROXY_ENGINES is not None:
        if engine in PROXY_ENGINES:
            return {"proxy": PROXY_URL}
        return {}
    # Legacy behavior: no PROXY_ENGINES means ALL engines use proxy
    return {"proxy": PROXY_URL}


def is_engine_allowed(engine: str) -> bool:
    """Check if a search engine is allowed."""
    if ALLOWED_SEARCH_ENGINES is None or not ALLOWED_SEARCH_ENGINES[0]:
        return engine in ALL_ENGINES
    return engine in ALLOWED_SEARCH_ENGINES


async def fetch_url(
    client: httpx.AsyncClient,
    url: str,
    headers: dict = None,
    max_retries: int = 2,
    timeout: float = 30.0,
) -> str:
    """Fetch URL content with error handling and retry logic.

    Args:
        client: httpx AsyncClient instance
        url: URL to fetch
        headers: Optional request headers
        max_retries: Number of retry attempts (default 2)
        timeout: Request timeout in seconds (default 30)

    Returns:
        Response text or error message.
    """
    last_error = None
    for attempt in range(max_retries + 1):
        try:
            response = await client.get(
                url, headers=headers or {}, timeout=timeout, follow_redirects=True
            )
            response.raise_for_status()
            return response.text
        except httpx.TimeoutException:
            last_error = f"Timeout fetching {url} (attempt {attempt + 1}/{max_retries + 1})"
        except httpx.HTTPStatusError as e:
            return f"Error fetching {url}: HTTP {e.response.status_code} {e.response.reason_phrase}"
        except Exception as e:
            last_error = f"Error fetching {url}: {str(e)} (attempt {attempt + 1}/{max_retries + 1})"

    return last_error or f"Error fetching {url}: unknown error"


async def search_bing(query: str, limit: int) -> list[dict]:
    """Search using Bing."""
    results = []
    async with httpx.AsyncClient(**get_proxy_config("bing")) as client:
        try:
            url = f"https://www.bing.com/search?q={urllib.parse.quote(query)}&count={limit}"
            headers = {"User-Agent": USER_AGENT}
            html = await fetch_url(client, url, headers)
            soup = BeautifulSoup(html, "lxml")

            for item in soup.select(".b_algo")[:limit]:
                title_elem = item.select_one("h2 a")
                snippet_elem = item.select_one(".b_caption p")
                if title_elem:
                    results.append({
                        "title": title_elem.get_text(strip=True),
                        "url": title_elem.get("href", ""),
                        "snippet": snippet_elem.get_text(strip=True) if snippet_elem else "",
                        "engine": "bing"
                    })
        except Exception as e:
            results.append({"error": f"Bing search failed: {str(e)}", "engine": "bing"})
    return results


async def search_duckduckgo(query: str, limit: int) -> list[dict]:
    """Search using DuckDuckGo."""
    results = []
    async with httpx.AsyncClient(**get_proxy_config("duckduckgo")) as client:
        try:
            url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
            headers = {"User-Agent": USER_AGENT}
            html = await fetch_url(client, url, headers)
            soup = BeautifulSoup(html, "lxml")

            for item in soup.select(".result")[:limit]:
                title_elem = item.select_one(".result__a")
                snippet_elem = item.select_one(".result__snippet")
                if title_elem:
                    results.append({
                        "title": title_elem.get_text(strip=True),
                        "url": title_elem.get("href", ""),
                        "snippet": snippet_elem.get_text(strip=True) if snippet_elem else "",
                        "engine": "duckduckgo"
                    })
        except Exception as e:
            results.append({"error": f"DuckDuckGo search failed: {str(e)}", "engine": "duckduckgo"})
    return results


async def search_brave(query: str, limit: int) -> list[dict]:
    """Search using Brave Search API."""
    results = []
    if not BRAVE_API_KEY:
        return [{"error": "Brave API key not configured", "engine": "brave"}]

    async with httpx.AsyncClient(**get_proxy_config("brave")) as client:
        try:
            url = "https://api.search.brave.com/res/v1/web/search"
            headers = {
                "Accept": "application/json",
                "X-Subscription-Token": BRAVE_API_KEY
            }
            params = {"q": query, "count": limit}

            response = await client.get(url, headers=headers, params=params, timeout=30.0)
            response.raise_for_status()
            data = response.json()

            for item in data.get("web", {}).get("results", [])[:limit]:
                results.append({
                    "title": item.get("title", ""),
                    "url": item.get("url", ""),
                    "snippet": item.get("description", ""),
                    "engine": "brave"
                })
        except Exception as e:
            results.append({"error": f"Brave search failed: {str(e)}", "engine": "brave"})
    return results


async def search_baidu(query: str, limit: int) -> list[dict]:
    """Search using Baidu."""
    results = []
    async with httpx.AsyncClient(**get_proxy_config("baidu")) as client:
        try:
            url = f"https://www.baidu.com/s?wd={urllib.parse.quote(query)}&rn={limit}"
            headers = {"User-Agent": USER_AGENT}
            html = await fetch_url(client, url, headers)
            soup = BeautifulSoup(html, "lxml")

            for item in soup.select(".result")[:limit]:
                title_elem = item.select_one("h3 a")
                snippet_elem = item.select_one(".c-abstract")
                if title_elem:
                    results.append({
                        "title": title_elem.get_text(strip=True),
                        "url": title_elem.get("href", ""),
                        "snippet": snippet_elem.get_text(strip=True) if snippet_elem else "",
                        "engine": "baidu"
                    })
        except Exception as e:
            results.append({"error": f"Baidu search failed: {str(e)}", "engine": "baidu"})
    return results


async def search_juejin(query: str, limit: int) -> list[dict]:
    """Search using Juejin."""
    results = []
    async with httpx.AsyncClient(**get_proxy_config("juejin")) as client:
        try:
            url = "https://api.juejin.cn/content_api/v1/search"
            headers = {"Content-Type": "application/json"}
            data = {
                "id_type": 2,
                "limit": limit,
                "sort_type": 200,
                "keyword": query,
                "search_type": 0
            }

            response = await client.post(url, headers=headers, json=data, timeout=30.0)
            response.raise_for_status()
            result = response.json()

            for item in result.get("data", [])[:limit]:
                results.append({
                    "title": item.get("article", {}).get("title", ""),
                    "url": f"https://juejin.cn/post/{item.get('article', {}).get('article_id', '')}",
                    "snippet": item.get("article", {}).get("brief_content", ""),
                    "engine": "juejin"
                })
        except Exception as e:
            results.append({"error": f"Juejin search failed: {str(e)}", "engine": "juejin"})
    return results


async def search_github(query: str, limit: int) -> list[dict]:
    """Search GitHub repositories."""
    results = []
    async with httpx.AsyncClient(**get_proxy_config("github")) as client:
        try:
            url = f"https://api.github.com/search/repositories?q={urllib.parse.quote(query)}&per_page={limit}"
            headers = {"Accept": "application/vnd.github.v3+json"}
            if GITHUB_TOKEN:
                headers["Authorization"] = f"token {GITHUB_TOKEN}"

            response = await client.get(url, headers=headers, timeout=30.0)
            response.raise_for_status()
            data = response.json()

            for item in data.get("items", [])[:limit]:
                results.append({
                    "title": item.get("full_name", ""),
                    "url": item.get("html_url", ""),
                    "snippet": item.get("description", "") or "",
                    "engine": "github"
                })
        except Exception as e:
            results.append({"error": f"GitHub search failed: {str(e)}", "engine": "github"})
    return results


async def search_github_code(query: str, limit: int) -> list[dict]:
    """Search GitHub code."""
    results = []
    async with httpx.AsyncClient(**get_proxy_config("github_code")) as client:
        try:
            url = f"https://api.github.com/search/code?q={urllib.parse.quote(query)}&per_page={limit}"
            headers = {"Accept": "application/vnd.github.v3+json"}
            if GITHUB_TOKEN:
                headers["Authorization"] = f"token {GITHUB_TOKEN}"

            response = await client.get(url, headers=headers, timeout=30.0)
            response.raise_for_status()
            data = response.json()

            for item in data.get("items", [])[:limit]:
                results.append({
                    "title": item.get("name", ""),
                    "url": item.get("html_url", ""),
                    "snippet": f"In repository: {item.get('repository', {}).get('full_name', '')}",
                    "engine": "github_code"
                })
        except Exception as e:
            results.append({"error": f"GitHub code search failed: {str(e)}", "engine": "github_code"})
    return results


async def search_tavily(query: str, limit: int) -> list[dict]:
    """Search using Tavily AI Search API."""
    results = []
    if not TAVILY_API_KEY:
        return [{"error": "Tavily API key not configured", "engine": "tavily"}]

    async with httpx.AsyncClient(**get_proxy_config("tavily")) as client:
        try:
            url = "https://api.tavily.com/search"
            headers = {"Content-Type": "application/json"}
            data = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "max_results": limit,
                "include_answer": True,
            }

            response = await client.post(url, headers=headers, json=data, timeout=30.0)
            response.raise_for_status()
            result = response.json()

            # Include AI-generated answer as first result
            if result.get("answer"):
                results.append({
                    "title": "[Tavily AI Answer]",
                    "url": "",
                    "snippet": result["answer"],
                    "engine": "tavily",
                    "score": 1.0,
                })

            for item in result.get("results", [])[:limit]:
                results.append({
                    "title": item.get("title", ""),
                    "url": item.get("url", ""),
                    "snippet": item.get("content", ""),
                    "engine": "tavily",
                    "score": item.get("score"),
                })
        except Exception as e:
            results.append({"error": f"Tavily search failed: {str(e)}", "engine": "tavily"})
    return results


# Search engine mapping
SEARCH_ENGINES = {
    "bing": search_bing,
    "duckduckgo": search_duckduckgo,
    "brave": search_brave,
    "baidu": search_baidu,
    "juejin": search_juejin,
    "github": search_github,
    "github_code": search_github_code,
    "tavily": search_tavily,
}


@mcp.tool()
async def web_search(query: str, engines: list[str] = None, limit: int = 10) -> str:
    """
    Search the web using one or more search engines simultaneously.
    
    Args:
        query: Search query string
        engines: Search engines to use (bing, duckduckgo, brave, baidu, csdn, juejin, zhihu, github, github_code)
        limit: Maximum number of results per engine (1-50, default 10)
    
    Returns:
        Formatted search results from all specified engines
    """
    if engines is None:
        engines = [DEFAULT_SEARCH_ENGINE]
    
    limit = min(max(limit, 1), 50)
    
    # Filter allowed engines
    engines = [e for e in engines if is_engine_allowed(e)]
    if not engines:
        engines = [DEFAULT_SEARCH_ENGINE] if is_engine_allowed(DEFAULT_SEARCH_ENGINE) else []
    
    if not engines:
        return "No allowed search engines configured"

    # Execute searches in parallel (each engine creates its own client with proxy config)
    tasks = [SEARCH_ENGINES[engine](query, limit) for engine in engines if engine in SEARCH_ENGINES]
    all_results = await asyncio.gather(*tasks)

    # Format results
    output = []
    for engine_results in all_results:
        for result in engine_results:
            if "error" in result:
                output.append(f"[{result['engine']}] Error: {result['error']}")
            else:
                output.append(f"[{result['engine']}] {result['title']}\n{result['url']}\n{result['snippet']}\n")

    return "\n".join(output) if output else "No results found"


@mcp.tool()
async def fetch_web_content(
    url: str,
    prompt: str = None,
    max_chars: int = 30000,
) -> str:
    """
    Fetch and extract text content from any public URL.

    Args:
        url: Public HTTP/HTTPS URL to fetch
        prompt: Optional hint for what to extract. When provided, the output
                is structured with the prompt as guidance. Useful for AI agents
                to focus on specific content (e.g., "extract code examples only",
                "summarize the main argument").
        max_chars: Maximum characters to return (default 30000)

    Returns:
        Extracted text content from the webpage, optionally guided by the prompt
    """
    async with httpx.AsyncClient(**get_proxy_config()) as client:
        headers = {"User-Agent": USER_AGENT}
        html = await fetch_url(client, url, headers)

        if html.startswith("Error"):
            return html

        soup = BeautifulSoup(html, "lxml")

        # Remove noisy elements
        for element in soup(
            [
                "script",
                "style",
                "nav",
                "header",
                "footer",
                "aside",
                "iframe",
                "noscript",
                "svg",
            ]
        ):
            element.decompose()

        # Remove common ad/sidebar containers by class/id patterns
        for element in soup.find_all(
            class_=re.compile(r"(ad-|banner|sidebar|promo|sponsored)", re.I)
        ):
            element.decompose()

        # Try to extract main article content
        article = soup.select_one("article") or soup.select_one("main") or soup.select_one("#content") or soup.select_one(".content")
        if article:
            for element in article(["script", "style"]):
                element.decompose()
            text = article.get_text(separator="\n", strip=True)
        else:
            text = soup.get_text(separator="\n", strip=True)

        # Clean up whitespace
        lines = (line.strip() for line in text.splitlines())
        text = "\n".join(line for line in lines if line)

        # Build output with optional prompt guidance
        if prompt:
            output = f"URL: {url}\nExtraction prompt: {prompt}\n\n{text}"
        else:
            output = f"URL: {url}\n\n{text}"

        if len(output) > max_chars:
            output = output[:max_chars] + "...\n[Content truncated]"

        return output
